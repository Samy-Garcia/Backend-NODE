import nodemailer from "nodemailer"; //envía correos electrónicos
import crypto from "crypto"; //genera tokens aleatorios
import jsonwebtoken from "jsonwebtoken"; //genera tokens JWT para autenticación
import bcryptjs from "bcryptjs"; //hashea contraseñas

import { config } from "../config.js"; //importa configuración del proyecto, como la clave secreta para JWT

import customerModel from "../models/customerModel.js"; //modelo de cliente para interactuar con la base de datos

//array de funciones
const registerCustomerController = {};

registerCustomerController.register = async (req, res) => {
    try {
        // 1 Solicitar datos a registrar
        let { name, lastName, birthDate, email, password, isVerified, loginAttemps, timeOut, } = req.body;

    // 2 Validar datos si ya existe la base de datos
    const existCustomer = await customerModel.findOne({ email });
    if (existCustomer) {
        return res.status(400).json({ message: 'Customer already exists' });
    }

        //encriptar contraseña
        const passwordHashed = await bcryptjs.hash(password, 10);
        
        //generar un codigo aleatorio
        const randomCode = crypto.randomBytes(3).toString("hex");

        //guardamos todo en un token
        const token = jsonwebtoken.sign(
            {
                randomCode,
                name,
                lastName,
                birthDate,
                email,
                password: passwordHashed,
                isVerified,
                loginAttemps,
                timeOut
            },
            //secret key
            config.JWT.secret,
            //tiempo de expiración del token
            { expiresIn: "15m" }

            );

             //guardamos el token en una cookie
            res.cookie("registrationCookie", token, {maxAge: 15 * 60 * 1000}) 
       
    } catch (error) {
        
    }
}

